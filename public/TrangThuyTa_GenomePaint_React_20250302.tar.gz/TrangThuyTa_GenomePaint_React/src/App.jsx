import React from 'react'
import DataTable from './components/ParseContent'

const App = () => {
  return (
    <DataTable />
  )
}

export default App